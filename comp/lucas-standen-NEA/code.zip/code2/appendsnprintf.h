char *appendsnprintf(char *buf, int size, char *format, ...);
