#include <stdio.h>
#include "util.h"

void printAST(astNode *head);
