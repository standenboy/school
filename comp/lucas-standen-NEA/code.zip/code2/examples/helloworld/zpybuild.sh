#!/bin/sh
zpy ./main.zpy -o main
