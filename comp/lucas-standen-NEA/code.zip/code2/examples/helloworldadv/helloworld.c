#include <zpylib.h>
void helloworld(){
printstr("hello world\n");
}
