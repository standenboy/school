void die(char *msg);
