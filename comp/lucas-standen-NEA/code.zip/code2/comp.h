#include "tokenizer.h"
#include <stdio.h>

#define MAXOUTLEN 512
void CompilerInit();
void Compile(astNode *node, FILE *f, char *strline);

