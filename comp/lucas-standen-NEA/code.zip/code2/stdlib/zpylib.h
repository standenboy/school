#include <String.h>
#include <stddef.h>
#include <stdlib.h>

void printstr(char *str);
void printchar(char c);
void printint(int i);
void printfloat(double f);
char *readstr();
int readint();
void readfloat(double f);
int randint(int lower, int upper);
