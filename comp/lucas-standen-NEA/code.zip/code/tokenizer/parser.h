char **parser(char *fileName); // general parser function
