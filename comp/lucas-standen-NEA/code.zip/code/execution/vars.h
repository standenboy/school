#include "../global/types.h"
void newVar(Vdef *definiton, literal *value);
literal *getVarCalled(char *name);
