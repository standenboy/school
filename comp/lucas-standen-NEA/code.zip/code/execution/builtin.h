#include <stdlib.h>
#include "../global/types.h"
#include "../global/util.h"

#define MAXARGS 8

void *doCall(ast_node *node);
